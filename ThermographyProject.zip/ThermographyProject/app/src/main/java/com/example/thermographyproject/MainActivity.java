package com.example.thermographyproject;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.*;

public class MainActivity extends AppCompatActivity {

    EditText inputValue;
    Spinner fromSpinner, toSpinner, definitionSpinner;
    TextView resultText, definitionText;
    Button convertButton;

    String[] units = {"Celsius", "Kelvin", "Fahrenheit"};

    String[] definitions = {
            "Celsius: A Celsius-skála a víz fagyáspontját 0°C-nál, forráspontját 100°C-nál definiálja.",
            "Kelvin: Abszolút hőmérsékleti skála, a 0 K az abszolút nulla, nem lehet negatív.",
            "Fahrenheit: A Fahrenheit-skála a víz fagyáspontját 32°F-nál, forráspontját 212°F-nál definiálja.",
            "Hőtan: A hőtan a hő, hőmérséklet és energiaátadás törvényeit vizsgáló fizikai tudományág."
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        inputValue = findViewById(R.id.inputValue);
        fromSpinner = findViewById(R.id.fromSpinner);
        toSpinner = findViewById(R.id.toSpinner);
        resultText = findViewById(R.id.resultText);
        convertButton = findViewById(R.id.convertButton);
        definitionSpinner = findViewById(R.id.definitionSpinner);
        definitionText = findViewById(R.id.definitionText);

        ArrayAdapter<String> unitAdapter = new ArrayAdapter<>(
                this,
                android.R.layout.simple_spinner_item,
                units
        );
        unitAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        fromSpinner.setAdapter(unitAdapter);
        toSpinner.setAdapter(unitAdapter);

        ArrayAdapter<String> definitionAdapter = new ArrayAdapter<>(
                this,
                android.R.layout.simple_spinner_item,
                definitions
        );
        definitionAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        definitionSpinner.setAdapter(definitionAdapter);

        definitionSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                definitionText.setText(definitions[position]);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                definitionText.setText("");
            }
        });


        convertButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                convert();
            }
        });
    }

    private void convert() {
        String inputStr = inputValue.getText().toString();
        if (inputStr.isEmpty()) {
            resultText.setText("Adj meg egy számot!");
            return;
        }

        double value = Double.parseDouble(inputStr);
        String from = fromSpinner.getSelectedItem().toString();
        String to = toSpinner.getSelectedItem().toString();

        double result = value;

        if (from.equals("Celsius") && to.equals("Kelvin")) {
            result = value + 273.15;
        } else if (from.equals("Celsius") && to.equals("Fahrenheit")) {
            result = value * 9 / 5 + 32;
        } else if (from.equals("Kelvin") && to.equals("Celsius")) {
            result = value - 273.15;
        } else if (from.equals("Kelvin") && to.equals("Fahrenheit")) {
            result = (value - 273.15) * 9 / 5 + 32;
        } else if (from.equals("Fahrenheit") && to.equals("Celsius")) {
            result = (value - 32) * 5 / 9;
        } else if (from.equals("Fahrenheit") && to.equals("Kelvin")) {
            result = (value - 32) * 5 / 9 + 273.15;
        }

        resultText.setText(String.format("Eredmény: %.2f", result));
    }
}
